#!/bin/sh
libtoolize --force --install
autoreconf --force --install

